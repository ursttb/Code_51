#include <STC89C5xRC.H>
#include"Delay.h"
#include"Nixie.h"

int main()
{
	while(1)
	{
		Nixie(7, NIXIENUM_5P);
		Nixie(5, NIXIENUM_2);
		Nixie(3, NIXIENUM_0);
	}
	return 0;
}