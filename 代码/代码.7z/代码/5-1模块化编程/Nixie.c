#include <STC89C5xRC.H>
#include"Delay.h"
#define NIXIENUM_0 0x3F
#define NIXIENUM_1 0x06
#define NIXIENUM_2 0x5B
#define NIXIENUM_3 0x4F
#define NIXIENUM_4 0x66
#define NIXIENUM_5 0x6D
#define NIXIENUM_6 0x7D
#define NIXIENUM_7 0x07
#define NIXIENUM_8 0x7F
#define NIXIENUM_9 0x6F

#define NIXIENUM_0P 0x3F + 0x80
#define NIXIENUM_1P 0x06 + 0x80
#define NIXIENUM_2P 0x5B + 0x80
#define NIXIENUM_3P 0x4F + 0x80
#define NIXIENUM_4P 0x66 + 0x80
#define NIXIENUM_5P 0x6D + 0x80
#define NIXIENUM_6P 0x7D + 0x80
#define NIXIENUM_7P 0x07 + 0x80
#define NIXIENUM_8P 0x7F + 0x80
#define NIXIENUM_9P 0x6F + 0x80

void Trans(unsigned char Loc, char CBA[3])
{
	char i = 2;
	while (Loc - 1)
	{
		CBA[i] = (Loc - 1) % 2;
		Loc = (Loc - 1) / 2 + 1;
		i--;
	}
	if (Loc - 1 == 1)
	{
		CBA[i] = 1;
	}
}

void Nixie(unsigned char Loc, num)
{
	char CBA[3] = { 0 };
	//ѡ��LEDλ��
	Trans(Loc, CBA);
	P24 = CBA[0];
	P23 = CBA[1];
	P22 = CBA[2];

	//�������ʾ����
	P0 = num; //ͼ����ʾ
	Delay(1); //�ȶ�ͼ����ʾ
	P0 = 0x00; //ͼ�����
}