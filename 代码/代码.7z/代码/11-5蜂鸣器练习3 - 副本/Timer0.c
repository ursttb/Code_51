#include <STC89C5xRC.H>
#include"Music.h"

void Timer0Init(void)
{
	TMOD |= 0x01;
	TL0 = 0x66;
	TH0 = 0xFC;

	ET0=1;
	EA=1;
	TR0 = 1;
}

void F() interrupt 1
{
	unsigned char i = 0;
	TL0 = 0x66;
	TH0 = 0xFC;
	i++;
//	if(i >= SPEED/4*BGM1[Music_i][1])
//	{
//		i = 0;
//		Music_i++;
//		Music_flag = 1;
//	}
}