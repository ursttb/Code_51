#include <STC89C5xRC.H>
#include "Music.h"
#include "LCD1602.h"

int main()
{
	unsigned char m = 0;
	LCD_Init();
	Play_BGM1();
	return 0;
}