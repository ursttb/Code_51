#include <STC89C5xRC.H>
#include "AT24C02.h"
#include "LCD1602.h"

unsigned char Clock[8][4] = {
	{0,0,0,0},
	{0,0,0,0},
	{0,0,0,0},
	{0,0,0,0},
	{0,0,0,0},
	{0,0,0,0},
	{0,0,0,0},
	{0,0,0,0}
};

unsigned char Show[8][4] = {
	{0,0,0,0},
	{0,0,0,0},
	{0,0,0,0},
	{0,0,0,0},
	{0,0,0,0},
	{0,0,0,0},
	{0,0,0,0},
	{0,0,0,0}
};

int main()
{
	unsigned char add = 0, pi = 0, pj = 0, xi = 0, xj = 0;
	LCD_Init();
//	//��������
//	for(add = 0,pi = 0;pi<8;pi++)
//	{
//		for(pj=0;pi<4;pj++,add++)
//		{
//			AT24C02_WriteByte(add,Clock[pi][pj]);
//		}
//	}
	//��ȡ����
	for(add = 0,pi = 0,xi = 1;pi<8;pi++)
	{
		for(xj = 1,pj=0;pi<4;pj++,add++,xj++)
		{
			if(xj == 16)
			{
				xi = 2;xj=1;
			}
			Show[pi][pj] = AT24C02_ReadByte(add);
			LCD_ShowNum(xi,xj,Show[pi][pj],1);
		}
	}	
	return 0;
}