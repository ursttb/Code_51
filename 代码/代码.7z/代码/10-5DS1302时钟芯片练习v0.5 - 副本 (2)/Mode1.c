#include "Public.h"
#include "DS1302.h"
#include "Key.h"
#include "LCD1602.h"
#include "Mode.h"

unsigned char Run(unsigned char n)//�ж�����
{

	if ((n % 4 == 0 && n % 100 != 0) || n % 400 == 0)
		return 1;
	else
		return 0;
}


void FormIns(unsigned char i)
{
	switch (i)
	{
		case 6:
		{
			//���ڼ��
			if(Time[i] <= 0)
			{
				Time[i] = 7;
			}
			if(Time[i] >=8)
			{
				Time[i] = 1;
			}
		}
		case 4:
		case 5: 
		{
			//����ͷּ��
			if (Time[i] == 255)
			{
				Time[i] = 59;
			}
			if (Time[i] > 59)
			{
				Time[i] = 0;
			}
			break;
		}
		case 3: 
		{
			//ʱ���
			if (Time[i] == 255)
			{
				Time[i] = 24;
			}
			if (Time[i] > 23)
			{
				Time[i] = 0;
			}
			break;
		}
		case 2: 
		{
			//�ռ��
			switch (Time[1])
			{
					case 1:
					case 3:
					case 5:
					case 7:
					case 8:
					case 10:
					case 12:
					{
						if (Time[i] < 1)
						{
							Time[i] = 31;
						}
						if (Time[i] > 31)
						{
							Time[i] = 1;
						}
						break;
					}
					case 2:
					{
						switch (Run(Time[0]))
						{
							case 1:
							{
								if (Time[i] < 1)
								{
									Time[i] = 29;
								}
								if (Time[i] > 29)
								{
									Time[i] = 1;
								}
								break;
							}
							default:
							{
								if (Time[i] < 1)
								{
									Time[i] = 28;
								}
								if (Time[i] > 28)
								{
									Time[i] = 1;
								}
								break;
							}
						}
						break;
					}
					case 4:
					case 6:
					case 9:
					case 11:
					{
						if (Time[i] < 1)
						{
							Time[i] = 30;
						}
						if (Time[i] > 30)
						{
							Time[i] = 1;
						}
						break;
					}
					default:
					{
						break;
					}
			}
			break;
		}
		case 1: 
		{
			//�¼��
			if (Time[i] < 1)
			{
				Time[i] = 12;
			}
			if (Time[i] > 12)
			{
				Time[i] = 1;
			}
			break;
		}
		case 0: 
		{
			//����
			if (Time[i] == 255)
			{
				Time[i] = 99;
			}
			if (Time[i] > 99)
			{
				Time[i] = 0;
			}
			break;
		}
	}

}



void Settime()
{
	unsigned char i = 0, temp = 0;
	while (1)
	{
		switch (Key())
		{
			case 0:
			{
				break;
			}
			case DK1: 
			{
				Mode = 0;//������ʾģʽ
				break; 
			}
			case DK2: 
			{
				i++;//��λ
				i = i % 7;//Խ��
				break;
			}
			case DK3: 
			{
				Time[i]++;
				for(temp = 0;temp<8;temp++){FormIns(temp);}
				break;
			}
			case DK4: 
			{
				Time[i]--;
				for(temp = 0;temp<8;temp++){FormIns(temp);}
				break;
			}	
		}	
		
		LCD_ShowString(1,3,"-"); LCD_ShowString(1,6,"-");
		LCD_ShowString(2,3,":"); LCD_ShowString(2,6,":");
		LCD_ShowString(1,10,"DAY:");
		if(Mode_Flashflag == 1 && i == 0){LCD_ShowString(1,1,"  ");} else{LCD_ShowNum(1,1,Time[0],2);}//��ʾ��
		if(Mode_Flashflag == 1 && i == 1){LCD_ShowString(1,4,"  ");} else{LCD_ShowNum(1,4,Time[1],2);}//��ʾ��
		if(Mode_Flashflag == 1 && i == 2){LCD_ShowString(1,7,"  ");} else{LCD_ShowNum(1,7,Time[2],2);}//��ʾ��
		if(Mode_Flashflag == 1 && i == 3){LCD_ShowString(2,1,"  ");} else{LCD_ShowNum(2,1,Time[3],2);}//��ʾʱ
		if(Mode_Flashflag == 1 && i == 4){LCD_ShowString(2,4,"  ");} else{LCD_ShowNum(2,4,Time[4],2);}//��ʾ��
		if(Mode_Flashflag == 1 && i == 5){LCD_ShowString(2,7,"  ");} else{LCD_ShowNum(2,7,Time[5],2);}//��ʾ��
		if(Mode_Flashflag == 1 && i == 6){LCD_ShowString(1,14,"  ");} else{LCD_ShowNum(1,14,Time[6],1);}//��ʾ����
				
		if (Mode == 0)
		{
			for(temp = 0;temp<8;temp++){FormIns(temp);}
			//�������õ�ʱ��д��DS1302
			DS1302_CE = 0;
			DS1302_SCLK = 0;
			
			DS1302_WriteByte(DS1302_WP,0x00);//ȡ��д����
			for(i = 0; i<8; i++)
			{
				DS1302_WriteByte(TimeAdd[i], DecTransBCD(Time[i]));
			}
			DS1302_WriteByte(DS1302_WP,0x80);//�ָ�д����			
			break;
		}
	}
	return;
}

