#include <STC89C5xRC.H>
#include "Public.h"
#include "Delay.h"
#include "Timer1.h"
#include "Music.h"
#include "LCD1602.h"
#include "DS1302.h"
#include "Key.h"

unsigned char Music_i = 0, FreqSelect = 0, Music_flag = 0, length = 0, Endtime = 0;

//������Ƶ�ʶ��ձ�
unsigned int code FreqTable[]={
	0,
63777,63872,63969,64054,64140,64216,64291,64360,64426,64489,64547,64603,
64655,64704,64751,64795,64837,64876,64913,64948,64981,65012,65042,65070,
65095,65120,65144,65166,65186,65206,65225,65242,65259,65274,65289,65303,
};
//����
unsigned char code BGM1[][2]={
	//����,ʱֵ,
	
		//1
	{  P, 4},
	{	P,	4},
	{	P,	4},
	{	M6,	2},
	{	M7,	2},
			
	{	H1,	4+2},
	{	M7,	2},
	{	H1,	4},
	{	H3,	4},
			
	{	M7,	4+4+4},
	{	M3,	2},
	{	M3,	2},
			
		//2	
	{	M6,	4+2},
	{	M5,	2},
	{	M6, 	4},	
	{	H1,	4},
			
	{	M5,	4+4+4},
	{	M3,	4},
			
	{	M4,	4+2},
	{	M3,	2},
	{	M4,	4},
	{	H1,	4},
			
		//3	
	{	M3,	4+4},
	{	P,		2},
	{	H1,	2},
	{	H1,	2},
	{	H1,	2},
			
	{	M7,	4+2},
	{	M4_,	2},	
	{	M4_,	4},	
	{	M7,	4},
			
	{	M7,	8},
	{	P,	   4},
	{	M6,	2},
	{	M7,	2},
			
		//4	
	{	H1,	4+2},
	{	M7,	2},
	{	H1,	4},
	{	H3,	4},
			
	{	M7,	4+4+4},
	{	M3,	2},
	{	M3,	2},
			
	{	M6,	4+2},
	{	M5,	2},
	{	M6,  4},	
	{	H1,	4},
			
		//5	
	{	M5,	4+4+4},
	{	M2,	2},
	{	M3,	2},
			
	{	M4,	4},
	{	H1,	2},
	{	M7,	2+2},
	{	H1,	2+4},
			
	{	H2,	2},
	{	H2,	2},
	{	H3,	2},
	{	H1,	2+4+4},
			
		//6	
	{	H1,	2},
	{	M7,	2},
	{	M6,	2},
	{	M6,	2},
	{	M7,	4},
	{	M5_,  4},	
			
			
	{	M6,	4+4+4},
	{	H1,	2},
	{	H2,	2},
			
	{	H3,	4+2},
	{	H2,	2},
	{	H3,	4},
	{	H5,	4},
			
		//7	
	{	H2,	4+4+4},
	{	M5,	2},
	{	M5,	2},
			
	{	H1,	4+2},
	{	M7,	2},
	{	H1,	4},
	{	H3,	4},
			
	{	H3,	4+4+4+4},
			
		//8	
	{	M6,	2},
	{	M7,	2},
	{	H1,	4},
	{	M7,	4},
	{	H2,	2},
	{	H2,	2},
			
	{	H1,	4+2},
	{	M5,	2+4+4},
			
	{	H4,	4},
	{	H3,	4},
	{	H3,	4},
	{	H1,	4},
			
		//9	
	{	H3,	4+4+4},
	{	H3,	4},
		
	{	H6,	4+4},
	{	H5,	4},
	{	H5,	4},
			
	{	H3,	2},
	{	H2,	2},
	{	H1,	4+4},
	{	P,	2},
	{	H1,	2},
			
		//10	
	{	H2,	4},
	{	H1,	2},
	{	H2,	2},
	{	H2,	4},
	{	H5,	4},
			
	{	H3,	4+4+4},
	{	H3,	4},
	
	{	H6,	4+4},
	{	H5,	4+4},
			
		//11	
	{	H3,	2},
	{	H2,	2},
	{	H1,	4+4},
	{	P,	2},
	{	H1,	2},
			
	{	H2,	4},
	{	H1,	2},
	{	H2,	2+4},
	{	M7,	4},
			
	{	M6,	4+4+4},
	{	P,	4},

	{0xFF,0}	//��ֹ��־
};



//void Showtext()
//{
//	if(okno == 1)
//	{
////		LCD_WriteCommand(0x01);
////		if(Time[3]<12&&Time[3]>=6)//����
////		{
////			LCD_ShowString(1,1,"Good morning,Sir");
////			LCD_ShowString(2,1,"Happy one day!");
////			Delay(1000);
////			LCD_WriteCommand(0x01);
////			LCD_ShowString(1,1,"You have    note");
//////			LCD_ShowNum(1,10,NoteNum,2);
////			LCD_ShowString(2,1,"Check it now?");
////		}
////		if(Time[3]>=12 && Time[3]<13)//����
////		{
////			LCD_ShowString(1,1,"Good noon,Sir");
//////			LCD_ShowString(2,1,"Sir");
////		}
////		if(Time[3]>=13 && Time[3]<18)//����
////		{
////			LCD_ShowString(1,1,"Good Afternoon");
////			LCD_ShowString(2,1,"Sir");
////		}
////		if(Time[3]>=18 && Time[3]<23)//����
////		if(Time[3]>=23 || Time[3]<6)//��ҹ

//	}
//	else if(okno == 2)
//	{
//		LCD_ShowString(1,11,"Error!");
//	}
//	else
//	{
//		LCD_ShowString(1,11,"      ");
//	}
//}



void Play_BGM1()
{
	LCD_ShowString(1,1,"Sir!");
	LCD_ShowString(2,1,"You have a date!");
	Timer1Init();
	while(1)
	{
		if(BGM1[Music_i][0]!=0xFF)	//�������ֹͣ��־λ
		{
			FreqSelect = BGM1[Music_i][0];
			length = BGM1[Music_i][1];
			if(Music_flag == 1)
			{
				Music_flag = 0;
				TR1 = 0;
				Delay(5);
				TR1 = 1;
			}
		}
		else	//�����ֹͣ��־λ
		{
			Endtime++;
			Delay(2000);
			Music_i = 0;
		}			
		
		if(Key()==MK16 || Endtime == 3)
		{
			Music_i = 0; TR1 = 0; 
			LCD_WriteCommand(0x01);
			break;
		}
	}
}