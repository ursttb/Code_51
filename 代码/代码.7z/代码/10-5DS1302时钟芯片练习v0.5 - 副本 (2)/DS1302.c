#include <STC89C5xRC.H>
#include "DS1302.h"
#include <Intrins.h>

unsigned char TimeAdd[7] = {
	0x8C, 0x88, 0x86, 0x84, 0x82, 0x80, 0x8A
};//��ӦDS1302���롢�֡�ʱ���ա��¡����ڡ���ĵ�ַ


unsigned char Time[7] = {
	23, 1, 19, 11, 49, 0, 4
};//��ӦDS1302���ꡢ�¡��ա�ʱ���֡��롢���ڵĳ�ʼֵ



void DS1302_Init()
{
	unsigned char i = 0;
	DS1302_CE = 0;
	DS1302_SCLK = 0;
	
//	DS1302_WriteByte(DS1302_WP,0x00);//ȡ��д����
//	for(i = 0; i<8; i++)
//	{
//		DS1302_WriteByte(TimeAdd[i], DecTransBCD(Time[i]));
//	}
//	DS1302_WriteByte(DS1302_WP,0x80);//�ָ�д����
}

void DS1302_WriteByte(unsigned char Command, Data)
{
	unsigned char i = 0;

	DS1302_CE = 1;
	
	for (i = 0; i < 8; i++)
	{
		DS1302_IO = Command & (0x01<<i);
		DS1302_SCLK = 1;
		DS1302_SCLK = 0;
	}

	for (i = 0; i < 8; i++)
	{
		DS1302_IO = Data & (0x01<<i);
		DS1302_SCLK = 1;
		DS1302_SCLK = 0;
	}

	DS1302_CE = 0;
}

unsigned char DS1302_ReadByte(unsigned char Command)
{
	unsigned char i = 0, Data = 0x00;
	Command |= 0x01;//�ĳɶ�ָ��(�޸���λ��)
	DS1302_CE = 1;

	for (i = 0; i < 8; i++)
	{
		DS1302_IO = Command & (0x01<<i);
		DS1302_SCLK = 0;
		DS1302_SCLK = 1;//�Ķ���1��0
	}

	for (i = 0; i < 8; i++)
	{
		DS1302_SCLK = 1;
		DS1302_SCLK = 0;
		if(DS1302_IO){Data|=(0x01<<i);}
	}
	
	DS1302_CE = 0;
	DS1302_SCLK = 1;
	DS1302_IO = 0;
	//DS1302_IO = 1;
	
	return Data;
}


void DS1302_ReadTime()//��DS1302�ж�ȡ����ʱ��
{
	unsigned char i = 0;
	for(i = 0;i<7;i++)
	{
		Time[i] = BCDTransDec(DS1302_ReadByte(TimeAdd[i]));
	}
}


//ʮ����תBCD
unsigned char DecTransBCD(unsigned char num)
{
	return num / 10 * 16 + num % 10;
}
//BCDתʮ����
unsigned char BCDTransDec(unsigned char num)
{
	return num / 16 * 10 + num % 16;
}