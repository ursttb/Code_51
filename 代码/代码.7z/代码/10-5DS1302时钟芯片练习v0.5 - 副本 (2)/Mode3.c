//#include "Public.h"
//#include "LCD1602.h"
//#include "Delay.h"

//#define KEYBORD_WT 1
//#define KEYBORD_Caps 2
//#define KEYBORD_NUM 3

//extern unsigned char Mode_Flashflag;

////unsigned char i = 0;

//unsigned char code board[9][8] = {
//	{0,7,9,1,',','.','?','!'},//MK4, MK8. MK12? MK16!
//	{'A','B','C',2,'a','b','c','+'},
//	{'D','E','F',3,'d','e','f','-'},
//	{'G','H','I',4,'g','h','i','*'},
//	{'J','K','L',5,'j','k','l','/'},
//	{'M','N','O',6,'m','n','o',':'},
//	{'P','Q','R','S','p','q','r','s'},//��7���ּ�����board[0][1]
//	{'T','U','V',8,'t','u','v',';'},
//	{'W','S','Y','Z','w','s','y','z'}//��9���ּ�����board[0][2]
//};

////����nλ״̬
//unsigned char bitIns(unsigned char byte,unsigned char i)
//{
//	if (byte & (0x01 << (i-1))){ return 1;}
//	else { return 0;}
//}

//unsigned char Write_keyboard(unsigned char *i,unsigned char *j)
//{
//	unsigned char num = ' ';
//	unsigned char AlShowflag = 0;
//	if (Key() == 0) return board[7][7];//ʲô����д
//	if (!bitIns(keystate, KEYBORD_WT))//д��״̬
//	{
//		if (Key() == MK13)//�˸��
//		{
//			if (*j == 1 && *i == 2)
//			{
//				//tempnote[0][15] = ' ';
//				*i = 1; *j = 16; return board[7][7];
//			}
//			else
//			{
//				//tempnote[i][j - 1] = ' '; 
//				*j--; return board[7][7];
//			}
//		}
//		if (Key() == MK4) return board[0][4];//���� ��
//		if (Key() == MK8) return board[0][5];//���� ��
//		if (Key() == MK12) return board[0][6];//���� ��
//		if (Key() == MK16) return board[0][7];//���� ��
//		switch (bitIns(keystate, KEYBORD_NUM))//�ж���ĸ��������
//		{
//			case 1:
//			{
//				//д����
//				if (Key() == MK9) return board[0][1];//����7
//				if (Key() == MK11) return board[0][2];//����9
//				if (Key() == MK14) return board[0][0];//����0
//				return board[Key() / 4 * 3 + Key() % 4 - 1][3];
//				break;
//			}
//			case 0:
//			{
//				unsigned char Ali = 0;
//				//д��ĸ
//				if (bitIns(keystate, KEYBORD_Caps))//Сд
//				{
//					Ali = 0;
//				}
//				else//��д
//				{
//					Ali = 4;
//				}
//				if (Key() == MK1 || Key() == MK2 || Key() == MK3 || Key() == MK5 || Key() == MK6 || Key() == MK7 || Key() == MK10 || Key() == MK15)
//				{
//					AlShowflag = 1;
//				}
//				if (Key() == MK9 || Key() == MK11)
//				{
//					AlShowflag = 2;
//				}
//				while (1)
//				{
//					if (AlShowflag == 1)
//					{
//						if (*i == 1 && *j < 15 && Mode_Flashflag == 1)
//						{
//							LCD_ShowChar(2, *j, board[Key() / 4 * 3 + Key() % 4 - 1][0 + Ali]);
//							LCD_ShowChar(2, *j, board[Key() / 4 * 3 + Key() % 4 - 1][1 + Ali]);
//							LCD_ShowChar(2, *j, board[Key() / 4 * 3 + Key() % 4 - 1][2 + Ali]);
//						}
//						if (*i == 2 && *j < 15 && Mode_Flashflag == 1)
//						{
//							LCD_ShowChar(1, *j, board[Key() / 4 * 3 + Key() % 4 - 1][0 + Ali]);
//							LCD_ShowChar(1, *j, board[Key() / 4 * 3 + Key() % 4 - 1][1 + Ali]);
//							LCD_ShowChar(1, *j, board[Key() / 4 * 3 + Key() % 4 - 1][2 + Ali]);
//						}
//						if (*i == 1 && *j >= 15 && Mode_Flashflag == 1)
//						{
//							LCD_ShowChar(2, 14, board[Key() / 4 * 3 + Key() % 4 - 1][0 + Ali]);
//							LCD_ShowChar(2, 15, board[Key() / 4 * 3 + Key() % 4 - 1][1 + Ali]);
//							LCD_ShowChar(2, 16, board[Key() / 4 * 3 + Key() % 4 - 1][2 + Ali]);
//						}
//						if (*i == 2 && *j >= 15 && Mode_Flashflag == 1)
//						{
//							LCD_ShowChar(1, 14, board[Key() / 4 * 3 + Key() % 4 - 1][0 + Ali]);
//							LCD_ShowChar(1, 15, board[Key() / 4 * 3 + Key() % 4 - 1][1 + Ali]);
//							LCD_ShowChar(1, 16, board[Key() / 4 * 3 + Key() % 4 - 1][2 + Ali]);
//						}
//					}
//					if (AlShowflag == 2)
//					{
//						if (*i == 1 && *j < 14 && Mode_Flashflag == 1)
//						{
//							LCD_ShowChar(2, *j, board[Key() / 4 * 3 + Key() % 4 - 1][0 + Ali]);
//							LCD_ShowChar(2, *j, board[Key() / 4 * 3 + Key() % 4 - 1][1 + Ali]);
//							LCD_ShowChar(2, *j, board[Key() / 4 * 3 + Key() % 4 - 1][2 + Ali]);
//							LCD_ShowChar(2, *j, board[Key() / 4 * 3 + Key() % 4 - 1][3 + Ali]);
//						}
//						if (*i == 2 && *j < 14 && Mode_Flashflag == 1)
//						{
//							LCD_ShowChar(1, *j, board[Key() / 4 * 3 + Key() % 4 - 1][0 + Ali]);
//							LCD_ShowChar(1, *j, board[Key() / 4 * 3 + Key() % 4 - 1][1 + Ali]);
//							LCD_ShowChar(1, *j, board[Key() / 4 * 3 + Key() % 4 - 1][2 + Ali]);
//							LCD_ShowChar(1, *j, board[Key() / 4 * 3 + Key() % 4 - 1][3 + Ali]);
//						}
//						if (*i == 1 && *j >= 14 && Mode_Flashflag == 1)
//						{
//							LCD_ShowChar(2, 13, board[Key() / 4 * 3 + Key() % 4 - 1][0 + Ali]);
//							LCD_ShowChar(2, 14, board[Key() / 4 * 3 + Key() % 4 - 1][1 + Ali]);
//							LCD_ShowChar(2, 15, board[Key() / 4 * 3 + Key() % 4 - 1][2 + Ali]);
//							LCD_ShowChar(2, 16, board[Key() / 4 * 3 + Key() % 4 - 1][3 + Ali]);
//						}
//						if (*i == 2 && *j >= 14 && Mode_Flashflag == 1)
//						{
//							LCD_ShowChar(1, 13, board[Key() / 4 * 3 + Key() % 4 - 1][0 + Ali]);
//							LCD_ShowChar(1, 14, board[Key() / 4 * 3 + Key() % 4 - 1][1 + Ali]);
//							LCD_ShowChar(1, 15, board[Key() / 4 * 3 + Key() % 4 - 1][2 + Ali]);
//							LCD_ShowChar(1, 16, board[Key() / 4 * 3 + Key() % 4 - 1][3 + Ali]);
//						}
//					}
//					if (Key() == MK13)//�˸������ֱ��������֮��Ҫ�и�������ʾ
//					{
//						break;
//					}
//					if (Key() == MK4) return board[Key() / 4 * 3 + Key() % 4 - 1][0 + Ali];
//					if (Key() == MK8) return board[Key() / 4 * 3 + Key() % 4 - 1][1 + Ali];
//					if (Key() == MK12) return board[Key() / 4 * 3 + Key() % 4 - 1][2 + Ali];
//					if (Key() == MK16 && AlShowflag == 2) return board[Key() / 4 * 3 + Key() % 4 - 1][3 + Ali];
//				}
//				break;
//			}
//		}
//	}

//}

//void Tsdirect_keyboard(unsigned char *i, unsigned char *j)
//{
//	if (bitIns(keystate, KEYBORD_WT))//����״̬
//	{
//		switch (Key())
//		{
//			case MK2:
//			{
//				//��������
//				*i--;
//				break;
//			}
//			case MK10:
//			{
//				//��������
//				*i++;
//				break;
//			}
//			case MK5:
//			{
//				//��������
//				*j--;
//				break;
//			}
//			case MK7:
//			{
//				//��������
//				*j++;
//				break;
//			}
//		}
//	}
//}

//void setNote()
//{
//	unsigned char i = 0,j = 0;
//	
//}