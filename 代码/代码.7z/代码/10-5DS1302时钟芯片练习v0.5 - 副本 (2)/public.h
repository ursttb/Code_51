#ifndef __PUBLIC_H__
#define __PUBLIC_H__

#include <STC89C5xRC.H>
#include "Music.h"

#define	MK1	1
#define	MK2	2
#define	MK3	3
#define	MK4	4
#define	MK5	5
#define	MK6	6
#define	MK7	7
#define	MK8	8
#define	MK9	9
#define	MK10 	10
#define	MK11 	11
#define	MK12 	12
#define	MK13 	13
#define	MK14 	14
#define	MK15 	15
#define	MK16 	16
#define	DK1	17
#define	DK2	18
#define	DK3	19
#define	DK4	20

extern unsigned char Mode,keystate;
void Init();
void Mode2_ClockRead();
unsigned char bitIns(unsigned char byte,unsigned char i);


#endif