#ifndef __MODE_H__
#define __MODE_H__

extern unsigned char Mode_Flashflag;

void LCDWork();
void LCDTimeShow();
void Mode_loop();


#endif