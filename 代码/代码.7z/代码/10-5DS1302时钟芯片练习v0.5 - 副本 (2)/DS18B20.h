#ifndef __DS18B20_H__
#define __DS18B20_H__

unsigned char OneWire_Init(void);
void OneWire_SendBit(unsigned char Bit);
unsigned char OneWire_ReceiveBit(void);
void OneWire_SendByte(unsigned char Byte);
unsigned char OneWire_ReceiveByte(void);
void DS18B20_ConvertT(void);
float DS18B20_ReadT(void);

#endif
