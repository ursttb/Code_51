#ifndef __MODE2_H__
#define __MODE2_H__


void setclock();
void Mode2_ClockRead();
void Mode2_ClockOn();

#endif