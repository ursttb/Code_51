#ifndef __KEY_H__
#define __KEY_H__

void Key(unsigned char* value);



#endif