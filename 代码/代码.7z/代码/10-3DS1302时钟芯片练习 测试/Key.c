#include <STC89C5xRC.H>
#include"Delay.h"

void Key(unsigned char* value)
{
	if (P31 == 0)
	{
		Delay(10);
		if (P31 == 0)
		{
			*value = 1;
		}
		while (!P31);
	}
	if (P30 == 0)
	{
		Delay(10);
		if (P30 == 0)
		{
			*value = 2;
		}
		while (!P30);
	}
	if (P32 == 0)
	{
		Delay(10);
		if (P32 == 0)
		{
			*value = 3;
		}
		while (!P32);
	}
	if (P33 == 0)
	{
		Delay(10);
		if (P33 == 0)
		{
			*value = 4;
		}
		while (!P33);
	}	

}
