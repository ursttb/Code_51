#include <STC89C5xRC.H>
#include "Music.h"


int main()
{
	Play_BGM1();
	return 0;
}