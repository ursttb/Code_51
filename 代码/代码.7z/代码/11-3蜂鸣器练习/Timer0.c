#include <STC89C5xRC.H>

void Timer0Init(void)
{
	TMOD |= 0x01;
	TL0 = 0x66;
	TH0 = 0xFC;

	ET0=1;
	EA=1;
	TR0 = 1;
}