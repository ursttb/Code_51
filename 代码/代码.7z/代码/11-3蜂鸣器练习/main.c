#include <STC89C5xRC.H>
#include"Music.h"

int main()
{
	while(1)
	{
		BGM1;
	}
	return 0;
}