#include <STC89C5xRC.H>


void Timer1Init(void)
{
	TMOD |= 0x10;
	TL1 = 0x66;//1ms
	TH1 = 0xFC;
	
	ET1 = 1;
	EA = 1;
	TR1 = 1;
}


//void Timer1_F()
//{
//	unsigned int i = 0;
//	TL1 = 0x66;
//	TH1 = 0xFC;
//	i++;
//	if(i == SPEED/4*Music[MusicSelect])
//	{
//		TransMC != TransMC;
//	}
//}