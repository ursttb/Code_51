#include <STC89C5xRC.H>
#include<intrins.h>
#define NIXIENUM_0 0x3F
#define NIXIENUM_1 0x06
#define NIXIENUM_2 0x5B
#define NIXIENUM_3 0x4F
#define NIXIENUM_4 0x66
#define NIXIENUM_5 0x6D
#define NIXIENUM_6 0x7D
#define NIXIENUM_7 0x07
#define NIXIENUM_8 0x7F
#define NIXIENUM_9 0x6F

unsigned char NixieTable[] = {0x3F, 0x06, 0x5B, 0x4F, 0x66, 0x6D, 0x7D, 0x07, 0x7F, 0x6F};

void Delay(unsigned int x)		//@11.0592MHz
{
	unsigned char i, j;

	_nop_();
	i = 2;
	j = 199;
	while(x--)
	{
		do
		{
			while (--j);
		} while (--i);
	}

}


void Trans(unsigned char Loc, char CBA[3])
{
	char i = 2;
	while (Loc - 1)
	{
		CBA[i] = (Loc - 1) % 2;
		Loc = (Loc - 1) / 2 + 1;
		i--;
	}
	if (Loc - 1 == 1)
	{
		CBA[i] = 1;
	}
}

void Nixie(unsigned char Loc, num)
{
	char CBA[3] = { 0 };
	//ѡ��LEDλ��
	Trans(Loc, CBA);
	P24 = CBA[0];
	P23 = CBA[1];
	P22 = CBA[2];

	//�������ʾ����
	P0 = NixieTable[num]; //ͼ����ʾ
	Delay(1); //�ȶ�ͼ����ʾ
	P0 = 0x00; //ͼ�����
}

int main()
{
	//	//ѡ��LED6, ���ӦY5��Ҳ����CBA = 101
	//	P24 = 1;
	//	P23 = 0;
	//	P22 = 1;
	//	//ѡ��LED3, ���ӦY2��Ҳ����CBA = 010
	//	P24 = 0;
	//	P23 = 1;
	//	P22 = 0;
	//	//ѡ�ж������ʾ6
	//	P0 = 0x7D;
		//while(1)
	while(1)
	{
		Nixie(7, 5);
		Nixie(5, 2);
		Nixie(3, 0);
	}
	return 0;
}