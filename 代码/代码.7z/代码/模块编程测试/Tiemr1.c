#include <STC89C5xRC.H>

void Timer1_Init()
{
	TMOD |= 0x10;
	TL1 = 0x66;
	TH1 = 0xFC;

	ET1 = 1;
	EA = 1;
	TR1 = 1;
}