#include <STC89C5xRC.H>
#include "Timer0.h"
#include "Key.h"
#include "LCD1602.h"
#include "Music.h"
#include "DS18B20.h"
#include "Delay.h"

extern void Showtemp();


int main()
{
	unsigned int temp = 0;
	P2=0x00;
	LCD_Init();
	while(1)
	{
		temp++;
		LCD_ShowNum(2,13,temp,4);
		if(P33 == 0)
		{
			break;
		}
		if(temp >= 1000)
		{
			temp = 0;
			break;
		}
	}
	P2=0xFF;
	while(1);
	return 0;
}

//void Timer0_Routine() interrupt 1
//{
//	static unsigned int T0Count_key, T0Count_music;
//	TL0 = 0x66;		//���ö�ʱ��ֵ
//	TH0 = 0xFC;		//���ö�ʱ��ֵ
//	T0Count_key++; T0Count_music++;
//	if (T0Count_key >= 20)//ÿ20us���һ��key�������ͷ�
//	{
//		Key_loop();
//		T0Count_key = 0;
//	}
//	if(T0Count_music >= SPEED/4*BGMlength + 5)
//	{
//		Music_loop();
//		T0Count_music = 0;
//	}
//}