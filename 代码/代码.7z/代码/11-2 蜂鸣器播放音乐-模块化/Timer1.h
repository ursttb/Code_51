#ifndef __TIMER1_H__
#define __TIMER1_H__

void Timer0Init(void);
void Timer1_Routine();
	
#endif
