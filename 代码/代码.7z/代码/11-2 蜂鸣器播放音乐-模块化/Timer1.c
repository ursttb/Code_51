#include <REGX52.H>
#include "Music.h"

/**
  * @brief  定时器0初始化，1毫秒@12.000MHz
  * @param  无
  * @retval 无
  */
void Timer1Init(void)
{
	TMOD |= 0x10;		//设置定时器模式
	TL1 = 0x18;		//设置定时初值
	TH1 = 0xFC;		//设置定时初值

	ET1=1;
	EA=1;
	TR1 = 1;		//定时器0开始计时
}

void Timer1_Routine() interrupt 3
{
	if(FreqTable[FreqSelect])	//如果不是休止符
	{
		/*取对应频率值的重装载值到定时器*/
		TL1 = FreqTable[FreqSelect]%256;		//设置定时初值
		TH1 = FreqTable[FreqSelect]/256;		//设置定时初值
		Buzzer=!Buzzer;	//翻转蜂鸣器IO口
	}
}