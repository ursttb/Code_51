#include <REGX52.H>
#include "Music.h"



void main()
{
	Play_BGM1();
}
