#include <STC89C5xRC.H>
#include"LCD1602.h"

int main()
{
	LCD_Init();
	LCD_ShowString(1,1,"I LOVE YOU");
	LCD_ShowNum(1,12, 123,3);
	LCD_ShowSignedNum(2,13,-66,2);
	LCD_ShowHexNum(2,1,0xA8,2);
	LCD_ShowBinNum(2,4,0xAA,8);
	while(1)
	{
		
	}
	return 0;
}