#include <STC89C5xRC.H>

int main()
{
	//P2 = 0xFE;//1111 1110;
	P2 = 0x55;
	return 0;
}