#include <REGX52.H>
#include <DELAY.H>
#include <MATRIXKEY.h>
#include <LCD1602.h>

unsigned char KeyNum;
char String[11]={'n','i','h','a','o','s','a','o','!'};
int main(void)
{
	LCD_Init();						           
	LCD_ShowChar(1,1,0x4A);
	LCD_ShowChar(1,2,0x4A);
	LCD_ShowChar(1,3,0x3A);
   LCD_ShowString(2,1,String);
	LCD_ShowChar(1,20,0x4A);
   LCD_ShowChar(1,21,0x4A);
	LCD_ShowChar(1,22,0x3A);
   LCD_ShowString(2,20,String);

	while(1)
	{
		LCD_WriteCommand(0x18);
		Delay(200);
	}
}