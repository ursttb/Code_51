#include <REGX52.H>
void Delay(unsigned int a)		//@11.0592MHz
{
	unsigned char i, j, k;
while(a--)
{
	_nop_();
	_nop_();
	i = 5;
	j = 52;
	k = 195;
	do
	{
		do
		{
			while (--k);
		} while (--j);
	} while (--i);
}
}

int main()
 {
	P2=0xFF;
	Delay(5);
	P2=0xEF;
	
 return 0;
 }