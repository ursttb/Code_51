#include <STC89C5xRC.H>
#include "AT24C02.h"
#include "LCD1602.h"

int main()
{
	unsigned char i = 124, j = 0;
	LCD_Init();
	AT24C02_WriteByte(100,i);
	j = AT24C02_ReadByte(0);
	LCD_ShowNum(1,1,j,3);
	return 0;
}