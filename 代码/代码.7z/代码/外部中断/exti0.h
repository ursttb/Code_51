#ifndef __EXTI0_H__
#define __EXTI0_H__

void exti0_init();
void exti0();


#endif