#include <STC89C5xRC.H>
#include"Delay.h"

void exti0_init()
{
	IT0 = 1;
	EX0 = 1;
	EA = 1;
}

void exti0() interrupt 0 //�ⲿ�ж�0�жϺ���
{
	Delay(20);//����
	if(P32==0)//�ٴ��ж�K3���Ƿ���
	{
		int i = 0, flag = 0;
		unsigned int x = 600;
		while(1)
		{
			if(flag == 1)
			{
				for(i = 0;i<8;i++ )
				{
					P2 = ~(1<<i);
					Delay(x);
				}	
			}
			if(flag == 0)
			{
				for(i = 7;i>=0;--i)
				{
					P2 = ~(1<<i);
					Delay(x);
				}	
			}
			flag = !flag;
			if(x>100)
			{
				x-=100;
			}
		}	
	}
}