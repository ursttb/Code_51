#include <STC89C5xRC.H>
#include"Delay.h"
#include"exti0.h"

void main()
{	
	exti0_init();//�ⲿ�ж�0����
	
	while(1)
	{			
							
	}		
}