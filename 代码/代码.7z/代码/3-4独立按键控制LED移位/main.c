#include <STC89C5xRC.H>
#include<intrins.h>

void Delay1ms(unsigned int x)		//@11.0592MHz
{
	unsigned char i, j;
	while(x--)
	{
		_nop_();
		i = 2;
		j = 199;
		do
		{
			while (--j);
		} while (--i);	
	}
}


int main()
{
	unsigned char LEDnum = 0;
	int i = 0;
	while(1)
	{
		if(P31 == 0)
		{
			Delay1ms(20);
			while(P31 == 0);
			Delay1ms(20);
			
			P2 = ~(1<<i);
			i++;
		}	
		if(i >7)
		{
			i = 0;
		}
	}
	return 0;
}