#include <STC89C5xRC.H>
#include"Delay.h"

unsigned char Key()
{
	unsigned char value = 0;
	if (P31 == 0)
	{
		Delay(10);
		if (P31 == 0)
		{
			value = 1;
		}
		while (!P31);
	}
	if (P30 == 0)
	{
		Delay(10);
		if (P30 == 0)
		{
			value = 2;
		}
		while (!P30);
	}
	if (P32 == 0)
	{
		Delay(10);
		if (P32 == 0)
		{
			value = 3;
		}
		while (!P32);
	}
	if (P33 == 0)
	{
		Delay(10);
		if (P33 == 0)
		{
			value = 4;
		}
		while (!P33);
	}	
	
	return value;
}

//#define	MK1	1
//#define	MK2	2
//#define	MK3	3
//#define	MK4	4
//#define	MK5	5
//#define	MK6	6
//#define	MK7	7
//#define	MK8	8
//#define	MK9	9
//#define	MK10 	10
//#define	MK11 	11
//#define	MK12 	12
//#define	MK13 	13
//#define	MK14 	14
//#define	MK15 	15
//#define	MK16 	16
//#define	DK1	17
//#define	DK2	18
//#define	DK3	19
//#define	DK4	20

//unsigned char key_r = 0;

//unsigned char Key()
//{
//	unsigned char temp;
//	temp = key_r;
//	key_r = 0;
//	return temp;
//}

//unsigned char Key_get()
//{
//	unsigned char value = 0;
//	if (P31 == 0)
//	{
//		value = DK1;
//	}
//	if (P30 == 0)
//	{
//		value = DK2;
//	}
//	if (P32 == 0)
//	{
//		value = DK3;
//	}
//	if (P33 == 0)
//	{
//		value = DK4;
//	}

//	//�������
//	P1 = 0x0F;
//	if (P1 != 0x0F)
//	{
//		P1 = 0x0F;
//		switch (P1)
//		{
//			case 0x07: value = 1; break;
//			case 0x0b: value = 2; break;
//			case 0x0d: value = 3; break;
//			case 0x0e: value = 4; break;
//		}

//		P1 = 0xF0;
//		switch (P1)
//		{
//			case 0x70: value = value; break;
//			case 0xb0: value = value + 4; break;
//			case 0xd0: value = value + 8; break;
//			case 0xe0: value = value + 12; break;
//		}
//	}
//	return value;
//}


//void Key_loop()
//{
//	static unsigned char keynuml = 0, keynumn = 0;//��Ҫ��̬����
//	keynuml = keynumn;
//	keynumn = Key_get();
//	if (keynumn == 0 && keynuml != 0)//�����ͷŸ�ֵ
//	{
//		key_r = keynuml;
//	}
//}

////void Timer0_Routine() interrupt 1
////{
////	static unsigned int T0Count_key;
////	TL0 = 0x66;		//���ö�ʱ��ֵ
////	TH0 = 0xFC;		//���ö�ʱ��ֵ
////	T0Count_key++;
////	if (T0Count_key >= 20)//ÿ20us���һ��key�������ͷ�
////	{
////		T0Count_key = 0;
////		Key_loop();
////	}
////}