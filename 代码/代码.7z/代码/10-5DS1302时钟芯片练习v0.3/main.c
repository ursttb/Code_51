#include "Init.h"
#include "Key.h"
#include "Mode.h"
#include "Timer0.h"

int main()
{
	Init();
	
	while(1)
	{
		LCDWork();
		Mode = Key();
		LCD_ShowNum(1,13,Mode,2);
	}
	return 0;
}

