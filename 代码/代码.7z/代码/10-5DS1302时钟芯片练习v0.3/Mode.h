#ifndef __MODE_H__
#define __MODE_H__

extern unsigned char Mode;

void LCDWork();
void LCDTimeShow();


#endif