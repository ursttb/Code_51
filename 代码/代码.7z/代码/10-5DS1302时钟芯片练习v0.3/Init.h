#ifndef __INIT_H__
#define __INIT_H__

#include <STC89C5xRC.H>
#include "DS1302.h"
#include "LCD1602.h"
#include "Timer0.h"

void Init();



#endif