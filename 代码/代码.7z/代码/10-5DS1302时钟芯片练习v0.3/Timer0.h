#ifndef __TIMER0_H__
#define __TIMER0_H__

extern unsigned char Mode1_Flashflag;
void Timer0_Init();
void Timer0_Routine();

#endif