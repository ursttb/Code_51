#ifndef __MODE1_H__
#define __MODE1_H__

unsigned char Run(unsigned char n);//�ж�����
void FormIns(unsigned char i);
void Settime();


#endif