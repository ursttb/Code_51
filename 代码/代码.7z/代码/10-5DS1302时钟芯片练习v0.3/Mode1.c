#include <STC89C5xRC.H>
#include "DS1302.h"
#include "Timer0.h"
#include "Key.h"
#include "LCD1602.h"
#include "Mode.h"


unsigned char Run(unsigned char n)//判断闰年
{

	if ((n % 4 == 0 && n % 100 != 0) || n % 400 == 0)
		return 1;
	else
		return 0;
}


void FormIns(unsigned char i)
{
	switch (i)
	{
		case 4:
		case 5: 
		{
			//秒检查和分检查
			if (Time[i] == 255)
			{
				Time[i] = 59;
			}
			if (Time[i] > 59)
			{
				Time[i] = 0;
			}
			break;
		}
		case 3: 
		{
			//时检查
			if (Time[i] == 255)
			{
				Time[i] = 24;
			}
			if (Time[i] > 24)
			{
				Time[i] = 0;
			}
			break;
		}
		case 2: 
		{
			//日检查
			switch (Time[1])
			{
					case 1:
					case 3:
					case 5:
					case 7:
					case 8:
					case 10:
					case 12:
					{
						if (Time[i] < 1)
						{
							Time[i] = 31;
						}
						if (Time[i] > 31)
						{
							Time[i] = 1;
						}
						break;
					}
					case 2:
					{
						switch (Run(Time[0]))
						{
							case 1:
							{
								if (Time[i] < 1)
								{
									Time[i] = 29;
								}
								if (Time[i] > 29)
								{
									Time[i] = 1;
								}
								break;
							}
							default:
							{
								if (Time[i] < 1)
								{
									Time[i] = 28;
								}
								if (Time[i] > 28)
								{
									Time[i] = 1;
								}
								break;
							}
						}
						break;
					}
					case 4:
					case 6:
					case 9:
					case 11:
					{
						if (Time[i] < 1)
						{
							Time[i] = 30;
						}
						if (Time[i] > 30)
						{
							Time[i] = 1;
						}
						break;
					}
					default:
					{
						break;
					}
			}
			break;
		}
		case 1: 
		{
			//月检查
			if (Time[i] < 1)
			{
				Time[i] = 12;
			}
			if (Time[i] > 12)
			{
				Time[i] = 1;
			}
			break;
		}
		case 0: 
		{
			//年检查
			if (Time[i] == 255)
			{
				Time[i] = 99;
			}
			if (Time[i] > 99)
			{
				Time[i] = 0;
			}
			break;
		}
	}

}



void Settime()
{
	unsigned char i = 0, temp = 0;
	while (1)
	{
		switch (Key())
		{
			case 0:
			{
				break;
			}
			case 1: 
			{
				Mode = 0;//返回显示模式
				break; 
			}
			case 2: 
			{
				i++;//移位
				i = i % 7;//越界
				break;
			}
			case 3: 
			{
				Time[i]++;
				for(temp = 0;temp<8;temp++){FormIns(temp);}
				break;
			}
			case 4: 
			{
				Time[i]--;
				for(temp = 0;temp<8;temp++){FormIns(temp);}
				break;
			}	
		}	
		
		LCD_ShowString(1,3,"-"); LCD_ShowString(1,6,"-");
		LCD_ShowString(2,3,":"); LCD_ShowString(2,6,":");
		if(Mode1_Flashflag == 1 && i == 0){LCD_ShowString(1,1,"  ");} else{LCD_ShowNum(1,1,Time[0],2);}//显示年
		if(Mode1_Flashflag == 1 && i == 1){LCD_ShowString(1,4,"  ");} else{LCD_ShowNum(1,4,Time[1],2);}//显示月
		if(Mode1_Flashflag == 1 && i == 2){LCD_ShowString(1,7,"  ");} else{LCD_ShowNum(1,7,Time[2],2);}//显示日
		if(Mode1_Flashflag == 1 && i == 3){LCD_ShowString(2,1,"  ");} else{LCD_ShowNum(2,1,Time[3],2);}//显示时
		if(Mode1_Flashflag == 1 && i == 4){LCD_ShowString(2,4,"  ");} else{LCD_ShowNum(2,4,Time[4],2);}//显示分
		if(Mode1_Flashflag == 1 && i == 5){LCD_ShowString(2,7,"  ");} else{LCD_ShowNum(2,7,Time[5],2);}//显示秒
				
		if (Mode == 0)
		{
			for(temp = 0;temp<8;temp++){FormIns(temp);}
			//将新设置的时间写入DS1302
			DS1302_CE = 0;
			DS1302_SCLK = 0;
			
			DS1302_WriteByte(DS1302_WP,0x00);//取消写保护
			for(i = 0; i<8; i++)
			{
				DS1302_WriteByte(TimeAdd[i], DecTransBCD(Time[i]));
			}
			DS1302_WriteByte(DS1302_WP,0x80);//恢复写保护			
			break;
		}
	}
	return;
}

