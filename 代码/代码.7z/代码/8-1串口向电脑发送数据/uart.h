#ifndef __UART_H__
#define __UART_H__

void uart_Init(unsigned char baud);
void uart_SendByte(unsigned char Byte);


#endif