#include <STC89C5xRC.H>
#include"Delay.h"
#include"uart.h"

unsigned char sec = 0;

int main()
{
	uart_Init(0xFA); //0xFA��9600
//	uart_SendByte(0x66);
	while(1)
	{
		uart_SendByte(sec);
		sec++;
		Delay(1000);
	}
	return 0;
}